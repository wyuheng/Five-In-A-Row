const {joinRoom} = require('./chessBoard.js');


function joinAIRoom(roomId, uId) {
    joinRoom(uId, roomId);
    joinRoom(roomId, AIName);

    const room = chessRoomMap.get(roomId);
    room.AI = new MCTSTree(room.board);
}


function requestHandler(uId, i, j, roomId) {
    console.log("Get uId:" + uId + " from clientMap");
    let ws = getClientMap(uId);
    if (uId != AIName && ws === undefined)
        throw new Error("Cannot find the ws of uId:" + uId);
    //for current implementation
    let {winning, isU1, lastMove} = putStone(uId, roomId, i, j);
    //send feedback to the user
    if (ws != undefined) {
        ws.send(JSON.stringify(
            {msgType : "update", uId : uId, success : winning, lastMove : lastMove, valid : true, isU1 : isU1}
        ));
    }
    //send update to the other user
    let room = chessRoomMap.get(roomId);
    let u2Id = room.u1Id == uId ? room.u2Id : room.u1Id;
    
    //If there's a winner, the game is over. Delete the chessRoom
    if (winning) {
        chessRoomMap.delete(roomId);
        deleteUserRoom(uId, roomId);
        deleteUserRoom(u2Id, roomId);
    }

    if (u2Id === AIName) {
        //let the AI play instead of sending msg to user2
        const currAI = chessRoomMap.get(roomId).AI;
        if (currAI === null || currAI === undefined)
            throw new Error("Not an AI room");
        currAI.updateMCTS(lastMove);
        const nextMoveOfAI = currAI.getBestMove();
        console.log("AI move to:" + nextMoveOfAI);
        requestHandler(AIName, nextMoveOfAI[0], nextMoveOfAI[1], roomId);
        return;
    }

    console.log("Get uId:" + u2Id + " from clientMap");
    const ws2 = getClientMap(u2Id);
    if (ws2 === undefined)
        throw new Error("Cannot find the ws of uId:" + uId);
    ws2.send(JSON.stringify(
        {msgType : "update", uId : uId, success : winning, lastMove : lastMove, valid : true, isU1 : isU1}
    ));
}